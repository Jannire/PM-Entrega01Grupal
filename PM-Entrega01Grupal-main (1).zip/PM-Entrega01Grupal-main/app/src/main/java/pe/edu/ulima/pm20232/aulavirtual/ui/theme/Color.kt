package pe.edu.ulima.pm20232.aulavirtual.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Orange400 = Color(0xFFFF5216)
val Orange800 = Color(0xFFF8B195)
val White400 = Color(0xFFFFFFFF)
val White800 = Color(0xFFFDFDFD)
val Gray800 = Color(0xFF43403E)
val Gray1200 = Color(0xFFe6e6e6)
val Gray400 = Color(0xFF242120)